import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { PropagateLoader } from "react-spinners";
import apiService from "../../service/api-service";
import SearchItemCard from "../seach-item-card/search-item-card";

import './search-item-component.css';

const SearchItemsComponent = () => {
    const [isLoading, setIsLoading] = useState(true);
    const [searchParams] = useSearchParams();
    const [seachData, setSearchData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                console.log("Search Parameters:", searchParams);
                const data = await apiService.searchMenuItemByUrl({
                    path: searchParams.toString(),
                    number: 50
                });
                setSearchData(data);
                setIsLoading(false);
            } catch (error) {
                console.error('Error fetching menu data:', error);
            }
        };

        fetchData();
    }, [searchParams]);

    return (
        isLoading ? (
            <div className='container mt-5 p-5 d-flex justify-content-center mb-5'>
                <PropagateLoader color='#49ceff' />
            </div>
        ) : (
            <div>

                <div className='search-container'>
                    {seachData.menuItems.map((seachItem) => (
                        <div className='product-card' key={seachItem.id}>
                            <SearchItemCard
                                title={seachItem.title}
                                price={200} height={200}
                                rating={'9.0'}
                                carbs={60}
                                protein={50}
                                fat={50}
                                calories={50}
                            />
                        </div>
                    ))}
                </div>
            </div>
        )
    );
};

export default SearchItemsComponent;
