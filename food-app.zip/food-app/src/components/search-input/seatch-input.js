import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

function SearchInput() {
  const [searchQuery, setSearchQuery] = useState('');
  const [minCalories, setMinCalories] = useState('');
  const [maxCalories, setMaxCalories] = useState('');
  const [minCarbs, setMinCarbs] = useState('');
  const [maxCarbs, setMaxCarbs] = useState('');
  const [minProtein, setMinProtein] = useState('');
  const [maxProtein, setMaxProtein] = useState('');
  const [minFat, setMinFat] = useState('');
  const [maxFat, setMaxFat] = useState('');

  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();

    const url = `/search?query=${searchQuery}` +
      `${minCalories !== '' ? `&minCalories=${minCalories}` : ''}` +
      `${maxCalories !== '' ? `&maxCalories=${maxCalories}` : ''}` +
      `${minCarbs !== '' ? `&minCarbs=${minCarbs}` : ''}` +
      `${maxCarbs !== '' ? `&maxCarbs=${maxCarbs}` : ''}` +
      `${minProtein !== '' ? `&minProtein=${minProtein}` : ''}` +
      `${maxProtein !== '' ? `&maxProtein=${maxProtein}` : ''}` +
      `${minFat !== '' ? `&minFat=${minFat}` : ''}` +
      `${maxFat !== '' ? `&maxFat=${maxFat}` : ''}`;

      navigate(url);
  };

  return (
    <form className="container mt-4" onSubmit={handleSearch}>
      <div className="row">
        <div className="col-md-4">
          <label htmlFor="searchQuery" className="form-label">Search:</label>
          <input
            type="text"
            className="form-control"
            id="searchQuery"
            placeholder="e.g., snickers"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <label htmlFor="minCalories" className="form-label">Min Calories:</label>
          <input
            type="number"
            className="form-control"
            id="minCalories"
            value={minCalories}
            onChange={(e) => setMinCalories(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <label htmlFor="maxCalories" className="form-label">Max Calories:</label>
          <input
            type="number"
            className="form-control"
            id="maxCalories"
            value={maxCalories}
            onChange={(e) => setMaxCalories(e.target.value)}
          />
        </div>
      </div>
      {/* Repeat similar row and column structure for the remaining input fields */}
      <div className="row mt-3">
        <div className="col-md-4">
          <label htmlFor="minCarbs" className="form-label">Min Carbs (g):</label>
          <input
            type="number"
            className="form-control"
            id="minCarbs"
            value={minCarbs}
            onChange={(e) => setMinCarbs(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <label htmlFor="maxCarbs" className="form-label">Max Carbs (g):</label>
          <input
            type="number"
            className="form-control"
            id="maxCarbs"
            value={maxCarbs}
            onChange={(e) => setMaxCarbs(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <label htmlFor="minProtein" className="form-label">Min Protein (g):</label>
          <input
            type="number"
            className="form-control"
            id="minProtein"
            value={minProtein}
            onChange={(e) => setMinProtein(e.target.value)}
          />
        </div>
      </div>
      <div className="row mt-3">
        <div className="col-md-4">
          <label htmlFor="maxProtein" className="form-label">Max Protein (g):</label>
          <input
            type="number"
            className="form-control"
            id="maxProtein"
            value={maxProtein}
            onChange={(e) => setMaxProtein(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <label htmlFor="minFat" className="form-label">Min Fat (g):</label>
          <input
            type="number"
            className="form-control"
            id="minFat"
            value={minFat}
            onChange={(e) => setMinFat(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <label htmlFor="maxFat" className="form-label">Max Fat (g):</label>
          <input
            type="number"
            className="form-control"
            id="maxFat"
            value={maxFat}
            onChange={(e) => setMaxFat(e.target.value)}
          />
        </div>
      </div>
      <div className="row mt-3">
        <div className="col-md-4">
          <button type="submit" className="btn btn-primary">Search</button>
        </div>
      </div>
    </form>
  );
}

export default SearchInput;
