import { HomePage } from "./home-page";
import { LoginPage } from "./login-page";
import { SingUpPage } from "./sign-up-page";
import { AboutPage } from "./about-page";

export default { HomePage, LoginPage, SingUpPage, AboutPage }