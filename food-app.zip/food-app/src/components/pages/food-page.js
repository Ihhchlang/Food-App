import React from "react";
import MenuComponent from "../../menu-component/menu-rename";

const FoodsPage = () => {

    return (
        <div className="container mt-5">
            <MenuComponent height={300 } query={'Soup'} />
            <MenuComponent height={500 } query={'Spagetti'} number={3} />
            <MenuComponent height={200 } query={'Doner'} />
        </div>
    )
}

export default FoodsPage