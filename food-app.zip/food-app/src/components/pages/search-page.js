import React from "react";
import SearchInput from "../search-input/seatch-input";
import SearchItemsComponent from "../seach-item/seach-item";


const SearchPage = () => {

    return (
        <div>
            <SearchInput />
            <SearchItemsComponent />
        </div>
    );
}
export default SearchPage