import React from "react";
import Avatar from "./avatar";
import './profile-header.css'
import background from '../../assets/pexels-eberhard-grossgasteiger-691668.jpg'

const ProfileHeader = ({ name, email }) => {

    return (
        <div className="profile-header-container">
            <img className="dark-overlay" src={background}></img>
            <Avatar name={name} />
            <h2 className="text-white">{name}</h2>
            <p className="text-white">Email: {email}</p>
        </div>
    )
}

export default ProfileHeader