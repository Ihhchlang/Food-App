import React from "react";
import { EmojiSmile } from "react-bootstrap-icons";
import './search-item-card.css'

const SearchItemCard = ({ title, price, height, rating, carbs, protein, fat, calories }) => {
    return (
        <div>
            <div className="search-card-container mt-5 ">
                <div className="search-card-header">
                    <h5 className="card-title">{title}</h5>
                </div>
                <div className="search-card-body">
                    <p>Carbs: {carbs}g</p>
                    <p>Protein: {protein}g</p>
                    <p>Fat: {fat}g</p>
                    <p>Calories: {calories} kcal</p>
                </div>
                <div className="search-card-footer">
                    <span>
                        {price} ₸ <EmojiSmile size={13} /> {rating}
                    </span>
                </div>
            </div>
        </div>
    );
};

export default SearchItemCard;
