import React, { useState, useEffect } from 'react';
import apiService from '../service/api-service';
import './menu-component.css'
import ImageTitleCard from '../components/image-title-card/image-title-card';
import { PropagateLoader } from "react-spinners";


const MenuComponent = ({ height, query, number }) => {
    number = number || 15
    const [menuData, setMenuData] = useState(null);
    const [isLoading, setIsLoading] = useState(true)

    useEffect(() => {
        const fetchData = async () => {
            try {
                const data = await apiService.searchMenuItem({ query: query, number: number });
                setMenuData(data);
                setIsLoading(false)
            } catch (error) {
                console.error('Error fetching menu data:', error);
            }
        };

        fetchData();
    }, []);

    return (
        isLoading ? (
            <div className='container mt-5  p-5 d-flex  justify-content-center mb-5'>
                <PropagateLoader color='#49ceff' />
            </div>
        ) : (
            <div>
                <div className='menu-container container'>
                    {menuData.menuItems.map((menuItem) => (
                        <div className='product-card' key={menuItem.id}>
                            <ImageTitleCard img={menuItem.image} title={menuItem.title} price={200} height={height} rating={'9.0'} />
                        </div>
                    ))}
                </div>
            </div>
        )
    );

};

export default MenuComponent;